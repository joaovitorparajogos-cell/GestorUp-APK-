# Plano de Simplificação — Escala Diária (GestorUp)

O objetivo é tornar a edição da escala diária ágil, permitindo digitação direta de horários e simplificando a interface.

## 1. Data Layer — Mudanças no Modelo
- **Entidade `EscalaItem`**: Adição do campo `val isFolga: Boolean = false`. O campo `horarioSaida` será mantido no banco por compatibilidade, mas ignorado na UI de edição diária.
- **Migração**: Necessária para atualizar o banco de dados (schema v3 para v4).

## 2. UI Layer — Nova Interface
- **Input de Horário**: Substituição de `TimePicker` por `OutlinedTextField` com:
  - Teclado numérico (`KeyboardType.Number`).
  - Máscara automática (`00:00`).
  - `VisualTransformation` para formatar a digitação.
  - Ação de teclado "Próximo" para navegar entre colaboradores.
- **Folga**: Adição de `Switch` para marcar "Folga", escondendo o campo de horário.
- **Card do Colaborador**: Interface compacta exibindo apenas nome e entrada (ou status de folga).

## 3. Detector de Interjornada
- O cálculo de interjornada será adaptado para buscar o horário de saída do dia anterior em registros históricos (ou exibir aviso de "dados incompletos" caso o horário de saída da jornada anterior não seja encontrado).

## 4. Procedimento de Teste
- Realizaremos os testes de:
  - Digitação de `07:00` / `07:30`.
  - Navegação entre campos (`Next` no teclado).
  - Marcação de Folga.
  - Salvamento e navegação de datas.
  - Validação do Detector de Interjornada.

---

Aguardando sua autorização para iniciar as modificações no banco de dados e na interface conforme este plano.
